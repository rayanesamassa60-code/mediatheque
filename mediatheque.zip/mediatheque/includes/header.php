<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Médiathèque</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header>
    <h1>Médiathèque</h1>
    <nav>
        <a href="index.php">Accueil</a>
        <a href="livre.php">Livres</a>
        <a href="adherents.php">Adhérents</a>
        <a href="emprunts.php">Emprunts en cours</a>
        <a href="emprunter.php">Nouvel emprunt</a>
        <a href="retour.php">Retours</a>
    </nav>
</header>
<main>

