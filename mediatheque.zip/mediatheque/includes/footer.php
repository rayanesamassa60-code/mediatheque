
<!-- footer.php -->
</main>
<footer><p>Médiathèque - Mini-projet BTS CIEL IR</p></footer>
</body>
</html>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Médiathèque</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>