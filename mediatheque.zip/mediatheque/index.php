<?php include 'includes/header.php'; ?>
<h2>Bienvenue</h2>
<p>Gérez les livres, les adhérents et les emprunts.</p>
<?php include 'includes/footer.php'; ?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
</body>
</html>
